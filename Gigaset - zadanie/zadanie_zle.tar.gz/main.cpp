#include "bigint.hh"

#include <iostream>

int main()
{
    bigint liczba;
    std::cin >> liczba;
    std::cout << liczba.silnia();

    return 0;
}


