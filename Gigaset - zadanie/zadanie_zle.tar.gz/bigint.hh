#ifndef __BIGINT_HH_INCLUDED__
#define __BIGINT_HH_INCLUDED__

/*****************************************************************************************************************************
*                                                   Biblioteka bigint                                                        *
*                                                                                                                            *
* Klasa pozwala na podstawowe operacje mnożenia, dzielenia, dodawania oraz odejmowania dużych liczb nieujemnych całkowitych. *
* Reprezentacja liczb to przechowywanie tylko jednej nieujemnej cyfry w jednej komórce tablicy (kontener vector).            *
*                                                                                                                            *
* Ograniczenia:                                                                                                              *
* - program nie jest zabezpieczony przed wprowadzeniem nieprawidłowych danych czyli typu innego niż int (cyfry).             *
* - w pętli for używa się zmiennej unsigned zamiast iteratorów, co powoduje ograniczenie wielkości liczb.                    *
* - w przypadku działania: dzielenia przez 0 lub odjęcia większej liczby zwracany jest obiekt typu bigint o wartości -1,     *
*   zamiast wprowadzenia obsługi błędów.                                                                                     *
*                                                                                                                            *
******************************************************************************************************************************/

#include <iostream>
#include <vector>
#include <cstdlib> /// atoi
#include <cstdio> /// stdin

class bigint{
    private:
        std::vector<char> tab;
    public:
         bigint();
         bigint(const bigint &);
         bigint(std::vector<char> _tab);
        ~bigint();

        bigint  silnia() const;
          void  dodaj_element(unsigned liczba);
          void  dodaj_element_na_poczatek(unsigned liczba);
      unsigned  rozmiar() const;

        bigint& operator  = (const bigint &obiekt);

  const bigint  operator  + (const bigint &obiekt) const;
  const bigint  operator  * (const bigint &obiekt) const;
  const bigint  operator  - (const bigint &obiekt) const;
  const bigint  operator  / (const bigint &obiekt) const;

        bigint& operator += (const bigint &obiekt);
        bigint& operator *= (const bigint &obiekt);
        bigint& operator -= (const bigint &obiekt);
        bigint& operator /= (const bigint &obiekt);

          bool  operator == (const bigint &obiekt) const;
          bool  operator != (const bigint &obiekt) const;
          bool  operator <= (const bigint &obiekt) const;
          bool  operator >= (const bigint &obiekt) const;
          bool  operator  < (const bigint &obiekt) const;
          bool  operator  > (const bigint &obiekt) const;

          char& operator [] (size_t i);
    const char& operator [] (size_t i) const;

        friend std::ostream& operator << (std::ostream &wyjscie, const bigint &obiekt);
        friend std::istream& operator >> (std::istream &wejscie,       bigint &obiekt);
};

#endif /// __BIGINT_HH_INCLUDED__

