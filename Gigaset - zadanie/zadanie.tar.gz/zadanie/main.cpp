#include "bigint.hh"

#include <iostream>

int main(int argc,char *argv[])
{
    if(argc == 2)
    {
        bigint liczba(argv[1]);
        std::cout << liczba.silnia() << std::endl;
    }
    else
    {
        bigint liczba;
        std::cin >> liczba;
        std::cout << liczba.silnia() << std::endl;
    }

    return 0;
}



