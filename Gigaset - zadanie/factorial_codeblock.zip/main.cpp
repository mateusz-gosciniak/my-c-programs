#include "bigint.hpp"

#include <iostream>

int main()
{
    bigint liczba;
    std::cin >> liczba;
    std::cout << liczba.silnia();

    return 0;
}



