
/*****************************************************************************************************************************
*                                                   Biblioteka bigint                                                        *
*                                                                                                                            *
* Klasa pozwala na podstawowe operacje mnożenia, dzielenia, dodawania oraz odejmowania dużych liczb nieujemnych całkowitych. *
* Reprezentacja liczb to przechowywanie tylko jednej nieujemnej cyfry w jednej komórce tablicy (kontener vector).            *
*                                                                                                                            *
* Ograniczenia:                                                                                                              *
* - program nie jest zabezpieczony przed wprowadzeniem nieprawidłowych danych czyli typu innego niż int (cyfry).             *
* - w pętli for używa się zmiennej unsigned zamiast iteratorów, co powoduje ograniczenie wielkości liczb.                    *
* - w przypadku działania: dzielenia przez 0 lub odjęcia większej liczby zwracany jest obiekt typu bigint o wartości -1,     *
*   zamiast wprowadzenia obsługi błędów.                                                                                     *
*                                                                                                                            *
******************************************************************************************************************************/

#include "bigint.hpp"

bigint:: bigint()                       : tab()     {}
bigint:: bigint(const bigint &o)        : tab()     {*this = o;}
bigint:: bigint(std::vector<char> _tab) : tab(_tab) {}
bigint::~bigint()                                   {}

/** ~~~~~~~~~~ bigint bigint::silnia() const ~~~~~~~~~~ **/

bigint bigint::silnia() const
{
    bigint jeden;
    jeden.dodaj_element(1);
    bigint zero;
    zero.dodaj_element(0);

    if( (*this == jeden) || (*this == zero) ) /// 0!=1 , 1! =1
        return jeden;

    return (*this) * ( ( (*this)-jeden ).silnia() ); /// n!=n(n-1)!
}

/** ~~~~~~~~~~ void bigint::dodaj_element(unsigned liczba) ~~~~~~~~~~ **/

void bigint::dodaj_element(unsigned liczba)
{
    this->tab.push_back(liczba);
}

/** ~~~~~~~~~~ void bigint::dodaj_element_na_poczatek(unsigned liczba) ~~~~~~~~~~ **/

void bigint::dodaj_element_na_poczatek(unsigned liczba)
{
    this->tab.insert(this->tab.begin(),liczba);
}

/** ~~~~~~~~~~ unsigned bigint::rozmiar() const ~~~~~~~~~~ **/

unsigned bigint::rozmiar() const
{
    return this->tab.size();
}

/** ~~~~~~~~~~ bigint& bigint::operator = (const bigint &obiekt) ~~~~~~~~~~ **/

bigint& bigint::operator = (const bigint &obiekt)
{
    this->tab.clear();
    this->tab = obiekt.tab;
    return *this;
}

/** ~~~~~~~~~~ const bigint bigint::operator + (const bigint &obiekt) const ~~~~~~~~~~ **/

const bigint bigint::operator + (const bigint &obiekt) const
{
    bigint wynik;

    /// w zależności czy dodaje liczbę większą czy mniejszą,
    /// wybieram sobie tą mniejszą, korzystając z tego że dodawanie jest przemienne.
    if( this->rozmiar() > obiekt.rozmiar() )
    {
        wynik = obiekt;
        int n = this->rozmiar() - wynik.rozmiar();

        if(n) for(int i=0;i<n;++i)
            wynik.dodaj_element_na_poczatek(0); /// dodaje zera, tak żeby indeksy tablic się zgadzały

        for(unsigned i=0;i<this->rozmiar();++i)
            wynik[i] += (*this)[i];
    }
    else
    {
        wynik = *this;
        int n = obiekt.rozmiar() - wynik.rozmiar();

        if(n) for(int i=0;i<n;++i)
            wynik.dodaj_element_na_poczatek(0);

        for(unsigned i=0;i<obiekt.rozmiar();++i)
            wynik[i] += obiekt[i];
    }

    for(int i=wynik.rozmiar()-1;i>=0;--i) /// sprawdzam tablicę od ostatniego indeksu
        if(wynik.tab[i] > 9) /// jeśli w jakimś indeksie jest liczba o wartości większej niż 9,
        {
            int n = (wynik.tab[i]-(wynik.tab[i]%10 ))/ 10; /// to zapamiętuje jej cyfrę dziesiątek.

            wynik.tab[i] = wynik.tab[i]%10; /// zostawiam tylko cyfrę jedności
            if( i-1 < 0 ) /// jeśli przekroczę indeks,
                wynik.dodaj_element_na_poczatek(n); /// to dodaję na początek nową komórkę, z zapamiętaną wartością dziesiątek
            else
                wynik.tab[i-1] = wynik.tab[i-1] + n; /// jeśli nie przekroczę indeksu to dodaje tę wartość do komórki wcześniej
        }

    return wynik;
}

/** ~~~~~~~~~~ const bigint bigint::operator * (const bigint &obiekt) const ~~~~~~~~~~ **/

const bigint bigint::operator * (const bigint &obiekt) const
{
    bigint wynik;
    bigint *wynik_skladowy;

    wynik_skladowy = new bigint[obiekt.rozmiar()]; /// wyników składowych jest tyle, z ilu składa się liczba przez którą mnożymy

    unsigned k=0;
    for(unsigned i=0;i<obiekt.rozmiar();++i)
    {
        for(unsigned j=0;j<this->rozmiar();++j)
            wynik_skladowy[k].dodaj_element( (*this)[j] * obiekt[i] ); /// mnożymy każdą liczbę przez siebie

        for(unsigned l=obiekt.rozmiar();(k+1)<l;--l) /// odpowiednio przesuwamy indeksy, jak w mnożeniu pisemnym
                wynik_skladowy[k].dodaj_element(0);

        k++;
    }

    for(unsigned i=0;i<obiekt.rozmiar();++i)
        wynik += wynik_skladowy[i]; /// dodajemy wszystkie wyniki składowe do siebie

    delete[] wynik_skladowy;
    return wynik;
}

/** ~~~~~~~~~~ const bigint bigint::operator - (const bigint &obiekt) const ~~~~~~~~~~ **/

const bigint bigint::operator - (const bigint &obiekt) const
{
    if(*this == obiekt)
    {
        bigint wynik;
        wynik.dodaj_element(0);
        return wynik;
    }

    if(*this < obiekt)
    {
        bigint wynik;
        wynik.dodaj_element(-1); /// #błąd odejmowania liczb nie ujemnych
        return wynik;
    }

    bigint wynik;
    wynik = obiekt;
    int n = this->rozmiar() - wynik.rozmiar();

    if(n) for(int i=0;i<n;++i)
        wynik.dodaj_element_na_poczatek(0); /// dbamy o to by indeksy się zgadzały

    for(unsigned i=0;i<wynik.rozmiar();++i)
        wynik[i] = (*this)[i] - wynik[i]; /// odejmujemy liczby, teraz mamy liczby ujemne w każdej komórce

    for(int i=wynik.rozmiar();0<i;--i) /// sprawdzamy całość od końca
    {
        if(wynik[i] < 0) /// jeśli, gdzieś jest liczba ujemna,
        {
            wynik[i] = wynik[i] + 10; /// to dodajemy do niej 10
            wynik[i-1] -= 1; /// a od poprzedniej odejmujemy 1, tak jak w odejmowaniu pisemnym
        }
    } /// nie musimy się martwić o przekroczenie indeksu, z tego względu, że odejmujemy zawsze liczbę mniejszą.

    for(unsigned i=0;i<wynik.rozmiar();++i)
    {
        if(wynik[i] == 0)
        {
            wynik.tab.erase(wynik.tab.begin()); /// czyścimy te zera, które wcześniej dodaliśmy, żeby indeks był zgodny.
            --i;
        }
        else
            break; /// przerywamy usuwanie tych zer, jak tylko na trafimy na pierwszą różną od zera liczbę.
    }

    return wynik;
}

/** ~~~~~~~~~~ const bigint bigint::operator / (const bigint &obiekt) const ~~~~~~~~~~ **/

const bigint bigint::operator / (const bigint &obiekt) const
{
    bigint a(*this);
    bigint b(obiekt);

    bigint wynik;
    wynik.dodaj_element(1);
    if(a == b)
        return wynik;

    bigint zero;
    if(b == zero)
    {
        zero.dodaj_element(-1);
        return zero; /// #błąd dzielenia przez 0
    }

    bigint jeden;
    jeden.dodaj_element(1);
    while(a > b) /// zliczamy ile razy możemy odjąć liczbę.
    {
        a -= b;
        wynik += jeden;
    }

    return wynik;
}

/** ~~~~~~~~~~ bigint& bigint::operator += (const bigint &obiekt) ~~~~~~~~~~ **/

bigint& bigint::operator += (const bigint &obiekt)
{
    *this = *this + obiekt;
    return *this;
}

/** ~~~~~~~~~~ bigint& bigint::operator *= (const bigint &obiekt) ~~~~~~~~~~ **/

bigint& bigint::operator *= (const bigint &obiekt)
{
    *this = *this * obiekt;
    return *this;
}

/** ~~~~~~~~~~ bigint& bigint::operator -= (const bigint &obiekt) ~~~~~~~~~~ **/

bigint& bigint::operator -= (const bigint &obiekt)
{
    *this = *this - obiekt;
    return *this;
}

/** ~~~~~~~~~~ bigint& bigint::operator /= (const bigint &obiekt) ~~~~~~~~~~ **/

bigint& bigint::operator /= (const bigint &obiekt)
{
    *this = *this / obiekt;
    return *this;
}

/** ~~~~~~~~~~ bool bigint::operator == (const bigint &obiekt) const ~~~~~~~~~~ **/

bool bigint::operator == (const bigint &obiekt) const
{
    if(this->rozmiar() == obiekt.rozmiar())
        for(unsigned i=0;i<obiekt.rozmiar();++i)
            if( (*this)[i] == obiekt[i] )
                continue;
            else
                return false;
    else
        return false;

    return true;
}

/** ~~~~~~~~~~ bool bigint::operator != (const bigint &obiekt) const ~~~~~~~~~~ **/

bool bigint::operator != (const bigint &obiekt) const
{
    if(this->rozmiar() != obiekt.rozmiar())
        return true;
    else
        for(unsigned i=0;i<obiekt.rozmiar();++i)
            if( (*this)[i] != obiekt[i] )
                return true;
            else
                continue;

    return false;
}

/** ~~~~~~~~~~ bool bigint::operator <= (const bigint &obiekt) const ~~~~~~~~~~ **/

bool bigint::operator <= (const bigint &obiekt) const
{
    if(this->rozmiar() < obiekt.rozmiar())
        return true;
    else if(this->rozmiar() == obiekt.rozmiar())
        for(unsigned i=0;i<obiekt.rozmiar();++i)
            if( (*this)[i] < obiekt[i] )
                return true;
            else if( (*this)[i] == obiekt[i] )
                continue;
            else
                return false;
    else
        return false;

    return true;
}

/** ~~~~~~~~~~ bool bigint::operator >= (const bigint &obiekt) const ~~~~~~~~~~ **/

bool bigint::operator >= (const bigint &obiekt) const
{
    if(this->rozmiar() > obiekt.rozmiar())
        return true;
    else if(this->rozmiar() == obiekt.rozmiar())
        for(unsigned i=0;i<obiekt.rozmiar();++i)
            if( (*this)[i] > obiekt[i] )
                return true;
            else if( (*this)[i] == obiekt[i] )
                continue;
            else
                return false;
    else
        return false;

    return true;
}

/** ~~~~~~~~~~ bool bigint::operator < (const bigint &obiekt) const ~~~~~~~~~~ **/

bool bigint::operator  < (const bigint &obiekt) const
{
    if(this->rozmiar() < obiekt.rozmiar())
        return true;
    else if(this->rozmiar() == obiekt.rozmiar())
        for(unsigned i=0;i<obiekt.rozmiar();++i)
            if( (*this)[i] < obiekt[i] )
                return true;
            else
                continue;

    return false;
}

/** ~~~~~~~~~~ bool bigint::operator  > (const bigint &obiekt) const ~~~~~~~~~~ **/

bool bigint::operator  > (const bigint &obiekt) const
{
    if(this->rozmiar() > obiekt.rozmiar())
        return true;
    else if(this->rozmiar() == obiekt.rozmiar())
        for(unsigned i=0;i<obiekt.rozmiar();++i)
            if( (*this)[i] > obiekt[i] )
                return true;
            else
                continue;

    return false;
}

/** ~~~~~~~~~~ char& bigint::operator [] (size_t i) ~~~~~~~~~~ **/

char& bigint::operator [] (size_t i)
{
    return this->tab[i];
}

/** ~~~~~~~~~~ const char& bigint::operator [] (size_t i) const ~~~~~~~~~~ **/

const char& bigint::operator [] (size_t i) const
{
    return this->tab[i];
}

/** ~~~~~~~~~~ std::ostream& operator << (std::ostream &wyjscie, const bigint &obiekt) ~~~~~~~~~~ **/

std::ostream& operator << (std::ostream &wyjscie, const bigint &obiekt)
{
    for(unsigned i=0;i<obiekt.rozmiar();++i)
        wyjscie << (short)obiekt[i];
    if(obiekt.rozmiar() == 0) wyjscie << "0";
    return wyjscie;
}

/** ~~~~~~~~~~ std::istream& operator >>(std::istream &wejscie, bigint &obiekt) ~~~~~~~~~~ **/

std::istream& operator >>(std::istream &wejscie, bigint &obiekt)
{
    char znak;
    while(znak != '\n')
    {
        znak=getc(stdin);
        if(isdigit(znak))
        {
            obiekt.dodaj_element(atoi(&znak));
            continue;
        }
        else
            break;
    }

    return wejscie;
}
